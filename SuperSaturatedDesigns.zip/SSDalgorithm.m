classdef SSDalgorithm < int16
    enumeration
        Marley (0)      
        Li     (1)       
        Jones  (2)   
    end
end

